#define GLM_FORCE_SIZE_T_LENGTH

#include <glm/glm.hpp>
#include <glm/ext.hpp>

int main()
{
	int Error = 0;

	return Error;
}

